<?php echo e($slot); ?>

<?php /**PATH D:\work1\callingManagement\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>