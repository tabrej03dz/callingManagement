<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-body">
            <!-- Form for setting instance and access -->
            <form action="<?php echo e(route('setInstanceAndAccess')); ?>" method="POST" class="row g-3">
                <?php echo csrf_field(); ?>
                <?php
                    $record = App\Models\UserInstanceAccess::where('user_id', auth()->user()->id)->first();
                ?>
                <div class="col-md-6">
                    <input type="text" class="form-control" name="instance_id" value="<?php echo e($record?->instance_id ?? ''); ?>"
                        placeholder="Instance Id">
                </div>
                <div class="col-md-6">
                    <input type="text" class="form-control" name="access_token"
                        value="<?php echo e($record?->access_token ?? ''); ?>" placeholder="Access Token">
                </div>
                <div class="col-md-6 mt-2">
                    <button type="submit" class="btn btn-primary w-100">Save</button>
                </div>
                <div class="col-md-6 mt-2">
                    <a href="<?php echo e(route('clearInstanceAndAccess')); ?>" class="btn btn-danger w-100">Clear</a>
                </div>
            </form>

            <!-- Button for creating demo -->
            <div class="text-center mt-3">
                <a href="<?php echo e(route('demo.create')); ?>" class="btn btn-danger">Create Demo</a>
            </div>
        </div>
    </div>


    <div class="card" style="overflow-x: auto;">
        <div class="card-body">
            <div class="table-responsive">
                <div class="table-wrapper" style="overflow-x: auto;">
                    <table id="example1" class="table table-bordered table-striped text-xs w-100">
                        <thead class="title-name-header w-full">
                            <tr>
                                <th style="min-width: auto;">#</th>
                                <th style="min-width: auto;">Name</th>
                                <th style="min-width: auto;">City</th>
                                <th style="min-width: 150px;">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $demoes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $demo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="d-md-table-row d-flex flex-column mb-4 p-3 bg-white rounded shadow-sm">
                                    <td class="d-block d-md-table-cell">
                                        <span class="font-weight-bold d-md-none">#: </span>
                                        <?php echo e($loop->iteration); ?>

                                    </td>
                                    <td class="d-block d-md-table-cell">
                                        <span class="font-weight-bold d-md-none">Name: </span>
                                        <?php echo e($demo->name); ?>

                                    </td>
                                    <td class="d-block d-md-table-cell">
                                        <span class="font-weight-bold d-md-none">City: </span>
                                        <?php echo e($demo->city); ?>

                                    </td>
                                    <td class="d-block d-md-table-cell">
                                        <span class="font-weight-bold d-md-none">Action: </span>
                                        <div class="btn-group d-flex flex-column flex-md-row">
                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit demo')): ?>
                                                <a href="<?php echo e(route('demo.edit', ['demo' => $demo->id])); ?>"
                                                    class="btn btn-primary btn-sm mb-2 mb-md-0 mr-md-2">Edit</a>
                                            <?php endif; ?>
                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete demo')): ?>
                                                <a href="<?php echo e(route('demo.images', ['demo' => $demo])); ?>"
                                                    class="btn btn-warning btn-sm">Images</a>
                                            <?php endif; ?>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    
    <style>
        @media (max-width: 768px) {
            .title-name-header {
                display: none;
            }
        }
    </style>
    
    <!-- /.card -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dash_layouts.aap', ['title' => 'Demos'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\work1\callingManagement\resources\views/dashboard/demo/index.blade.php ENDPATH**/ ?>