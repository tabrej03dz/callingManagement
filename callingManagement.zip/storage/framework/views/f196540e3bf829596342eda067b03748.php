<?php $__env->startSection('content'); ?>


    <!-- /.card -->
    <div class="card" style="overflow-x: auto;">
        <div class="card-header">
            <h3 class="card-title">DataTable with default features</h3>
        </div>
        <!-- /.card-header -->

        <div class="card-body">
            <table id="example1" class="table table-bordered table-striped" >
                <thead>
                <tr>
                    <th>Phone Number</th>
                    <th>Response</th>
                    <th>Description</th>
                    <th>Last Call</th>
                    <th>Have to call</th>
                    <th>Count</th>
                    <?php if (\Illuminate\Support\Facades\Blade::check('role', 'super_admin|admin')): ?>
                    <th>Assigned User</th>
                    <?php endif; ?>
                    <th>Action</th>
                    
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $user->userNumbers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $number): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $record = $number->number->callRecords()->latest()->first();
                        //dd($record->status);
                    ?>
                    <tr>
                        <td><?php echo e($number->number->phone_number); ?></td>
                        <td><?php echo e($record?->response); ?></td>
                        <td><?php echo e($record?->description); ?></td>
                        <td><?php echo e($record?->created_at); ?></td>
                        <td><?php echo e($record?->have_to_call); ?></td>
                        <td><?php echo e($number->number->callRecords->count()); ?></td>
                        <?php if (\Illuminate\Support\Facades\Blade::check('role', 'super_admin|admin')): ?>
                            <td><?php echo e($number->user->name); ?></td>
                        <?php endif; ?>
                        <td>
                            <div class="btn-group">
                                <a href="<?php echo e(route('callRecord.show', ['number' => $number->id])); ?>" class="btn btn-primary">Call Records</a>
                                
                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        <!-- /.card-body -->
    </div>
    <!-- /.card -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('dash_layouts.aap', ['title' => 'Assigned Numbers to '. $user->name], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\work1\callingManagement\resources\views/dashboard/user/assignedNumbers.blade.php ENDPATH**/ ?>