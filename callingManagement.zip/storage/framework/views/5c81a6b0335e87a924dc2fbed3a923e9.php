<?php $__env->startSection('content'); ?>

    <div class="card">
        <div class="card-body">
            <?php
                //$users = App\Models\User::whereDoesntHave('roles', function ($query) {
                //    $query->where('name', 'super_admin');
                //})->get();
                $users = App\Models\User::all();

            ?>

            <div class="row">
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($user->hasRole('super_admin')): ?>
                        <?php continue; ?>
                    <?php endif; ?>
                    <?php if(!auth()->user()->hasRole(['super_admin', 'admin'])): ?>
                        <?php if(auth()->user()->id != $user->id): ?>
                            <?php continue; ?>
                        <?php endif; ?>
                    <?php endif; ?>

                    <div class="col-lg-2 col-4">
                        <!-- small box -->
                        <div class="small-box bg-success">
                            <div class="inner">
                                <?php
                                    $userCallRecords = \App\Models\CallRecord::where('user_id', $user->id);
                                    if ($from == null && $to == null){
                                        $userCallRecords = $userCallRecords->whereDate('created_at', \Carbon\Carbon::today());
                                    }else{
                                        $userCallRecords = $userCallRecords->whereBetween('created_at', [$from, $to]);
                                    }
                                    if ($status != 'all'){
                                        $userCallRecords = $userCallRecords->where('status', $status);
                                    }
                                    $userCallRecords = $userCallRecords->get();
                                ?>
                                <h3> <?php echo e($userCallRecords->count()); ?><sup style="font-size: 20px"></sup></h3>
                                <p><?php echo e($user->name); ?></p>
                            </div>
                            <div class="icon">
                                <i class="ion ion-pie-graph"></i>
                            </div>
                            
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
    <!-- /.card -->



    <div class="card">

        <div class="card-header">
            <h3 class="card-title">Count: <?php echo e($callRecords->count()); ?></h3>
        </div>

        <div class="card-body">
            <form action="<?php echo e(route('callRecord.statusWise', ['status' => $status ?? 'all'])); ?>" method="GET" class="form-inline mb-3">
                <div class="row w-100">
                    <div class="col-12 col-sm-4 col-md-3 mb-2 mb-sm-0">
                        <input type="date" name="from" placeholder="From" class="form-control w-100">
                    </div>
                    <div class="col-12 col-sm-4 col-md-3 mb-2 mb-sm-0">
                        <input type="date" name="to" placeholder="To" class="form-control w-100">
                    </div>
                    <div class="col-12 col-sm-4 col-md-2 mb-2 mb-sm-0">
                        <button type="submit" class="btn btn-primary w-100 w-md-auto">Filter</button>
                    </div>
                    <div class="col-12 col-sm-4 col-md-2">
                        <a href="<?php echo e(route('callRecord.dayWise')); ?>" class="btn btn-secondary w-100 w-md-auto">Clear</a>
                    </div>
                </div>
            </form>


            <div class="table-responsive">
                <table id="example1" class="table table-bordered table-striped">
                    <thead>
                        <tr>
                            <th>Number</th>
                            <th>Status</th>
                            <th>Description</th>
                            <th>Called At</th>
                            <th>Have to call</th>
                            <th>Call By</th>
                             
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $callRecords; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $record): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($record->number->phone_number); ?></td>
                                <td><?php echo e($record->status); ?></td>
                                <td><?php echo e($record->description); ?></td>
                                <td><?php echo e($record->created_at); ?></td>
                                <td><?php echo e($record->have_to_call); ?></td>
                                <td><?php echo e($record->user->name); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>


        </div>
        <!-- /.card-body -->
    </div>
    <!-- /.card -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('dash_layouts.aap', ['title' => ucfirst($status).' Call Records'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\work1\callingManagement\resources\views/dashboard/callRecord/dayWise.blade.php ENDPATH**/ ?>