<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Rvg Calling</title>

        <!-- Fonts -->
        <link rel="preconnect" href="https://fonts.bunny.net">
        <link href="https://fonts.bunny.net/css?family=figtree:400,600&display=swap" rel="stylesheet" />


        <link href="img/favicon.png" rel="icon">
        <link href="img/favicon.png" rel="apple-touch-icon">

        <!-- Google Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Montserrat:100,200,300&display=swap" rel="stylesheet">

        <!-- Bootstrap & Font-awesome File -->
        <link href="<?php echo e(asset('asset/landing/inc/bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('asset/landing/inc/font-awesome/css/font-awesome.min.css')); ?>" rel="stylesheet">

        <!-- Main Stylesheet File -->
        <link href="<?php echo e(asset('asset/landing/css/style.css')); ?>" rel="stylesheet">

        <!-- Styles -->





    </head>
    <body class="antialiased">

    <!-- Header Section Start -->
    <header class="bg-light py-5 " style="background-image:url(<?php echo e(asset('asset/landing//img/header-bg.jpg')); ?>);background-size: cover; background-position: center;">
        <div class="container text-center">
            <div class="row justify-content-center">
                <div class="col-12 mb-4">
                    <h1 class="display-4"><a class="brand text-white text-decoration-none" href="">Rvg Calling System</a></h1>
                    <!-- Uncomment the following line if you want to use the logo image instead of text -->
                    <!-- <a class="brand" href=""><img class="img-fluid" alt="Logo" src="img/logo.jpg"></a> -->
                </div>

                <div class="col-12">
                    <h2 class="h4 text-white mb-4">An Innovative Calling Management</h2>

                    <?php if(Route::has('login')): ?>
                        <div class="position-center top-0 end-0 p-3">
                            <?php if(auth()->guard()->check()): ?>
                                <a href="<?php echo e(url('/dashboard')); ?>"
                                   class="btn btn-outline-danger font-weight-bold">Dashboard</a>
                            <?php else: ?>
                                <a href="<?php echo e(route('login')); ?>"
                                   class="btn btn-outline-danger font-weight-bold">Log in</a>

                                
                                
                                
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </header>
    <!-- Header Section End -->


    <!-- About Section Start -->
        <div class="about">
            <div class="container">
                <div class="section-header">
                    <h2>About Our App</h2>
                </div>
                <div class="row align-items-center">
                    <div class="col-md-6 img-cols">
                        <div class="img-col">
                            <div class="img">
                                <img src="<?php echo e(asset('asset/landing/img/about.jpg')); ?>">
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 content-cols">
                        <div class="content-col content-col-1">
                            <h3>Lorem ipsum dolor</h3>
                            <p>
                                Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam fringilla justo justo. Proin sodales bibendum pharetra. Aliquam blandit sapien eu nisl dictum pretium. Proin ac orci et ipsum vehicula rutrum eget eu ex.
                            </p>
                            <p>
                                Nam fringilla justo justo. Proin sodales bibendum pharetra. Aliquam blandit sapien eu nisl dictum pretium. Proin ac orci et ipsum vehicula rutrum eget.
                            </p>
                            <a href="https://htmlcodex.com">Learn More</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- About Section End -->

        <!-- Feature Section Start -->
        <div class="feature">
            <div class="container">
                <div class="section-header">
                    <h2>Features</h2>
                </div>
                <div class="row align-items-center text-center">
                    <div class="col-md-3 col-sm-12">
                        <div class="f-item">
                            <a href=""><i class="fa fa-adjust"></i></a>
                            <h3>Lorem ipsum</h3>
                            <p>Lorem ipsum dolor sit amet adipiscing elit. Mauris vitae neque tristique diam</p>
                        </div>
                        <div class="f-item">
                            <a href=""><i class="fa fa-headphones"></i></a>
                            <h3>Lorem ipsum</h3>
                            <p>Lorem ipsum dolor sit amet adipiscing elit. Mauris vitae neque tristique diam</p>
                        </div>
                    </div>
                    <div class="col-md-6 d-none d-md-block">
                        <div class="f-img">
                            <img src="<?php echo e(asset('asset/landing/img/mobile.png')); ?>" alt="Mobile Image" />
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-12">
                        <div class="f-item">
                            <a href=""><i class="fa fa-wifi"></i></a>
                            <h3>Lorem ipsum</h3>
                            <p>Lorem ipsum dolor sit amet adipiscing elit. Mauris vitae neque tristique diam</p>
                        </div>
                        <div class="f-item">
                            <a href=""><i class="fa fa-volume-up"></i></a>
                            <h3>Lorem ipsum</h3>
                            <p>Lorem ipsum dolor sit amet adipiscing elit. Mauris vitae neque tristique diam</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Feature Section End -->


        <!-- jQuery & Bootstrap File -->
        <script src="<?php echo e(asset('asset/landing/vendor/jquery/jquery.min.js')); ?>"></script>
        <script src="<?php echo e(asset('asset/landing/vendor/jquery/jquery-migrate.min.js')); ?>"></script>
        <script src="<?php echo e(asset('asset/landing/vendor/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
    </body>
</html>
<?php /**PATH D:\work1\callingManagement\resources\views/welcome.blade.php ENDPATH**/ ?>