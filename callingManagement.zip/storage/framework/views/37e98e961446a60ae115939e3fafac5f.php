<?php $__env->startSection('content'); ?>
    <script src="https://cdn.tailwindcss.com"></script>
    <?php if(session()->has('alreadyAssigned') && session('alreadyAssigned')): ?>
        <div class="card">
            <div class="card-head">
                <h6 class="ml-4 mt-3 mb-0">These numbers had been assigned to another user</h6>
            </div>
            <div class="card-body">
                <div class="alert alert-warning">
                    <form action="<?php echo e(route('number.unAssign')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th scope="col">Assigned Numbers</th>
                                        <th scope="col">Assigned User</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = session('alreadyAssigned'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $assigned): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td class="d-flex align-items-center">
                                                <input type="checkbox" name="alreadyAssignedNumbers[]" hidden checked
                                                    value="<?php echo e($assigned->id); ?>" class="mr-2">
                                                <span><?php echo e($assigned->number->phone_number); ?></span>
                                            </td>
                                            <td>
                                                <?php $__currentLoopData = $assigned->number->userNumbers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $userNumber): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <span>Name: <?php echo e($userNumber->user?->name); ?>, Assigned At:
                                                        <?php echo e($userNumber->assigned_at); ?>, Assigned By:
                                                        <?php echo e($userNumber->assignedBy?->name); ?></span>
                                                    <br>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>

                        </div>
                        <div class="form-group">
                            <input type="submit" class="btn btn-danger mr-2" value="Cancel">
                            <a href="<?php echo e(route('number.index')); ?>" class="btn btn-success">Yes! Keep It</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    <?php endif; ?>

    <div class="card">
        <div class="card-body">
            <form action="<?php echo e(route('number.index')); ?>" method="get">
                <div class="row g-3 align-items-center">
                    <div class="col-12 col-sm-6 col-md-3 mb-md-2">
                        <label for="city" class="visually-hidden">City</label>
                        <input type="text" class="form-control" id="city" name="city" placeholder="City">
                    </div>
                    <div class="col-12 col-sm-6 col-md-3 mb-md-2">
                        <label for="from" class="visually-hidden">From</label>
                        <input type="date" class="form-control" id="from" name="from" placeholder="From">
                    </div>
                    <div class="col-12 col-sm-6 col-md-3 mb-md-2">
                        <label for="to" class="visually-hidden">To</label>
                        <input type="date" class="form-control" id="to" name="to" placeholder="Date">
                    </div>
                    <div class="col-6 col-md-3 mt-4">
                        <button type="submit" class="btn btn-primary w-100">Apply</button>
                    </div>
                    <div class="col-6 col-md-3 mt-4">
                        <a href="<?php echo e(route('number.index')); ?>" class="btn btn-secondary w-100">Clear</a>
                    </div>
                </div>
            </form>
        </div>
    </div>




    <!-- /.card -->
    <div class="card">

        <form action="<?php echo e(route('number.assignToUser')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <div class="card-header">
                <h3 class="card-title">DataTable with default features</h3>
            </div>
            <!-- /.card-header -->

            <div class="card-body">
                <div class="form-row align-items-center">
                    <div class="col-12 col-sm-auto">
                        <label for="userSelect" class="col-form-label">Select User</label>
                        <select class="form-control" id="userSelect" name="user_id">
                            <option value="">Select User</option>
                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($user->id); ?>"><?php echo e($user->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    
                    
                    
                    
                    
                    
                    
                    

                    <div class="col-12 col-sm-auto">
                        <label for="itemsInput" class="col-form-label">Items</label>
                        <input type="number" id="itemsInput" class="form-control w-100 w-sm-auto" name="items"
                            placeholder="Items">
                    </div>

                    <?php
                        //$subQuery = App\Models\Number::select('id')
                        //    ->whereIn('id', function ($query) {
                        //        $query->select(\DB::raw('MIN(id)'))
                        //              ->from('numbers')
                        //              ->groupBy('city');
                        //    });

                        //$records = App\Models\Number::whereIn('id', $subQuery)->get();
                        $records = App\Models\Number::select('city', DB::raw('count(*) as total'))
                            ->groupBy('city')
                            ->get();
                    ?>

                    <div class="col-12 col-sm-auto">
                        <label for="citySelect" class="col-form-label">City</label>
                        <select name="city" class="form-control w-100 w-sm-auto" id="citySelect">
                            <option value="">Choose City</option>
                            <?php $__currentLoopData = $records; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $record): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($record->city); ?>"><?php echo e($record->city); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="col-12 col-sm-auto mt-9">
                        <input type="submit" value="Assign" class="btn btn-success w-100 w-sm-auto">
                    </div>
                </div>
            </div>

        </form>
        <form action="<?php echo e(route('number.checkedDelete')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="card-body">
                <input type="submit" value="Delete" class="btn btn-danger col-12 col-sm-auto mb-4"
                    aria-label="Delete item">
                <div class="table-responsive">
                    <table id="example1" class="table table-bordered table-striped">
                        <thead>
                            <tr>
                                <th>
                                    <div class="form-check">
                                        <input class="form-check-input" type="checkbox" id="selectAll">
                                        <label class="form-check-label" for="selectAll">All</label>
                                    </div>
                                </th>
                                <th>Business Name</th>
                                <th>Phone Number</th>
                                <th>City</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $numbers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $number): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>
                                        <div class="form-check">
                                            <input class="form-check-input" name="numbers[]" value="<?php echo e($number->id); ?>"
                                                type="checkbox" id="<?php echo e($number->id); ?>">
                                            <label class="form-check-label"></label>
                                        </div>
                                    </td>
                                    <td>
                                        <label class="form-check-label"
                                            for="<?php echo e($number->id); ?>"><?php echo e($number->business_name); ?></label>
                                    </td>
                                    <td><?php echo e($number->phone_number); ?></td>
                                    <td><?php echo e($number->city); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <!-- /.card-body -->
        </form>
        <?php echo e($numbers->links()); ?>

    </div>
    <!-- /.card -->

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const selectAllCheckbox = document.getElementById('selectAll');
            const checkboxes = document.querySelectorAll('input[name="numbers[]"]');

            selectAllCheckbox.addEventListener('change', function() {
                checkboxes.forEach(checkbox => {
                    checkbox.checked = selectAllCheckbox.checked;
                });
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dash_layouts.aap', ['title' => 'Numbers'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\work1\callingManagement\resources\views/dashboard/number/index.blade.php ENDPATH**/ ?>