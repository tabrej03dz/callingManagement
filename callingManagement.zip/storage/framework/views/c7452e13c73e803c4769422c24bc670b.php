<?php $__env->startSection('content'); ?>
    <script src="https://cdn.tailwindcss.com"></script>
    <?php if(session()->has('alreadyAssigned') && session('alreadyAssigned')): ?>
        <div class="card">
            <div class="card-head">
                <h6 class="ml-4 mt-3 mb-0">These numbers had been assigned to another user</h6>
            </div>
            <div class="card-body">
                <div class="alert alert-warning">
                    <form action="<?php echo e(route('number.unAssign')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th scope="col">Assigned Numbers</th>
                                        <th scope="col">Assigned User</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = session('alreadyAssigned'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $assigned): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td class="d-flex align-items-center">
                                                <input type="checkbox" name="alreadyAssignedNumbers[]" hidden checked
                                                    value="<?php echo e($assigned->id); ?>" class="mr-2">
                                                <span><?php echo e($assigned->number->phone_number); ?></span>
                                            </td>
                                            <td>
                                                <?php $__currentLoopData = $assigned->number->userNumbers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $userNumber): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <span>Name: <?php echo e($userNumber->user?->name); ?>, Assigned At:
                                                        <?php echo e($userNumber->assigned_at); ?>, Assigned By:
                                                        <?php echo e($userNumber->assignedBy?->name); ?></span>
                                                    <br>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>

                        </div>
                        <div class="form-group">
                            <input type="submit" class="btn btn-danger mr-2" value="Cancel">
                            <a href="<?php echo e(route('number.index')); ?>" class="btn btn-success">Yes! Keep It</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    <?php endif; ?>

    <div class="card">
        <div class="card-body">
            <form action="<?php echo e(route('number.index')); ?>" method="get" class="row gy-3 gx-4 align-items-end">
                <div class="col-12 col-sm-6 col-lg-4 col-xl-3">
                    <label for="city" class="form-label">City</label>
                    <input type="text" class="form-control" id="city" name="city" placeholder="Enter city">
                </div>
                <div class="col-12 col-sm-6 col-lg-4 col-xl-3">
                    <label for="from" class="form-label">From</label>
                    <input type="date" class="form-control" id="from" name="from">
                </div>
                <div class="col-12 col-sm-6 col-lg-4 col-xl-3">
                    <label for="to" class="form-label">To</label>
                    <input type="date" class="form-control" id="to" name="to">
                </div>
                <div class="col-12 col-lg-4 col-xl-6 d-flex gap-3 mt-3 mt-lg-0">
                    <button type="submit" class="btn btn-primary flex-grow-1 w-100 w-sm-auto">Apply</button>
                    <a href="<?php echo e(route('number.index')); ?>"
                        class="btn btn-outline-secondary flex-grow-1 w-100 w-sm-auto">Clear</a>
                </div>
            </form>

            <?php if (\Illuminate\Support\Facades\Blade::check('role', 'super_admin')): ?>
                <hr class="my-2">
                <div class="d-flex flex-column flex-sm-row gap-3 justify-content-center">
                    <a href="<?php echo e(route('number.allDelete')); ?>"
                        onclick="return confirm('Are you sure you want to delete all numbers?')"
                        class="btn btn-danger w-sm-auto w-lg-50">Delete All Numbers</a>
                    <a href="<?php echo e(route('number.unassignedDelete')); ?>" class="btn btn-danger w-sm-auto w-lg-50"
                        onclick="return confirm('Are you sure you want to delete all unassigned numbers?')">Delete Unassigned
                        Numbers</a>
                </div>
            <?php endif; ?>
        </div>
    </div>




    <!-- /.card -->
    <div class="card">

        <form action="<?php echo e(route('number.assignToUser')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">DataTable with default features</h3>
                </div>
                <!-- /.card-header -->

                <div class="card-body">
                    <div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 row-cols-lg-4 g-3 align-items-end">
                        <div class="col">
                            <label for="userSelect" class="form-label">Select User</label>
                            <select class="form-control" id="userSelect" name="user_id">
                                <option value="">Select User</option>
                                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($user->id); ?>"><?php echo e($user->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <div class="col">
                            <label for="itemsInput" class="form-label">Items</label>
                            <input type="number" class="form-control" id="itemsInput" name="items" placeholder="Items">
                        </div>

                        <?php
                            $records = App\Models\Number::select('city', DB::raw('count(*) as total'))
                                ->groupBy('city')
                                ->get();
                        ?>

                        <div class="col">
                            <label for="citySelect" class="form-label">City</label>
                            <select name="city" class="form-control" id="citySelect">
                                <option value="">Choose City</option>
                                <?php $__currentLoopData = $records; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $record): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($record->city); ?>"><?php echo e($record->city); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="col-12 col-sm-auto mt-2">
                            <input type="submit" value="Assign" class="btn btn-success w-100">
                        </div>
                    </div>
                </div>
            </div>
        </form>


        <form action="<?php echo e(route('number.checkedDelete')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="card-body">
                <?php if (\Illuminate\Support\Facades\Blade::check('role', 'super_admin|admin')): ?>
                    <div class="col-12 col-sm-6 col-lg-3 mb-3">
                        <input type="submit" value="Delete" class="btn btn-danger w-100">
                    </div>
                <?php endif; ?>
                <div class="table-responsive">
                    <table id="example1" class="table table-bordered table-striped">
                        <thead>
                            <tr>
                                <th>#</th>
                                <?php if (\Illuminate\Support\Facades\Blade::check('role', 'super_admin|admin')): ?>
                                    <th>
                                        <div class="form-check">
                                            <input class="form-check-input" type="checkbox" id="selectAll">
                                            <label class="form-check-label" for="selectAll">All</label>
                                        </div>
                                    </th>
                                <?php endif; ?>
                                <th>Business Name</th>
                                <th>Phone Number</th>
                                <th>City</th>
                                <th>Assigned User</th>
                                
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $numbers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $number): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($loop->iteration); ?></td>
                                    <td>
                                        <div class="form-check">
                                            <input class="form-check-input" name="numbers[]" value="<?php echo e($number->id); ?>"
                                                type="checkbox" id="<?php echo e($number->id); ?>">
                                            <label class="form-check-label"></label>
                                        </div>
                                    </td>
                                    <td>
                                        <label class="form-check-label"
                                            for="<?php echo e($number->id); ?>"><?php echo e($number->business_name); ?></label>
                                    </td>
                                    <td><?php echo e($number->phone_number); ?></td>
                                    <td><?php echo e($number->city); ?></td>
                                    <td>
                                        <?php $__currentLoopData = $number->userNumbers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php echo e($user->user->name); ?>

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
                <!-- /.card-body -->
        </form>
        <?php echo e($numbers->links()); ?>

    </div>
    <!-- /.card -->
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const selectAllCheckbox = document.getElementById('selectAll');
            const checkboxes = document.querySelectorAll('input[name="numbers[]"]');

            selectAllCheckbox.addEventListener('change', function() {
                checkboxes.forEach(checkbox => {
                    checkbox.checked = selectAllCheckbox.checked;
                });
            });
        });
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('dash_layouts.aap', ['title' => 'Numbers'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\work1\callingManagement\resources\views/dashboard/number/all.blade.php ENDPATH**/ ?>