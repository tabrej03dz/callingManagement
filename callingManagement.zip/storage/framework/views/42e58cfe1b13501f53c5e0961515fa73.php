<footer class="main-footer">
    <strong>Copyright &copy; <?php echo e(date('Y')); ?><a href="">Real Victory</a>.</strong>
    All rights reserved.
    <div class="float-right d-none d-sm-inline-block">
        <b>realvictorygroups@gmail.com</b>
    </div>
</footer>
<?php /**PATH D:\work1\callingManagement\resources\views/dash_layouts/footer.blade.php ENDPATH**/ ?>