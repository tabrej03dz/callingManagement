<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-body">
            <form role="form" action="<?php echo e(route('user.update', ['user' => $user])); ?>" method="post" enctype="multipart/form-data" >
                <?php echo csrf_field(); ?>
                <div class="form-group mb-3">
                    <input name="name" type="text" class="form-control" placeholder="Name" value="<?php echo e($user->name); ?>" />
                </div>
                <div class="form-group mb-3">
                    <input name="email" type="email" class="form-control" placeholder="Email" value="<?php echo e($user->email); ?>" />
                </div>
                <div class="form-group mb-3">
                    <select name="role_name" class="form-control custom-select">
                        <option value="">Role</option>
                        <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($role->name); ?>"><?php echo e($role->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="form-group mb-3">
                    <input name="password" type="password" class="form-control" placeholder="Password"/>
                </div>
                <div class="form-group mb-3">
                    <input name="confirm_password" type="password" class="form-control" placeholder="Confirm Password"/>
                </div>
                <div class="form-group mb-3">
                    <button type="submit" class="btn btn-primary">Submit</button>
                </div>
            </form>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dash_layouts.aap', ['title' => 'Edit User'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\work1\callingManagement\resources\views/dashboard/user/edit.blade.php ENDPATH**/ ?>