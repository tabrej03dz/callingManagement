<?php $__env->startSection('content'); ?>
<div class="card shadow-lg rounded-lg overflow-hidden">
    <div class="card-header bg-primary text-white p-3">
        <h5 class="mb-0 font-weight-bold">All Users</h5>
    </div>
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover mb-0">
                <thead class="bg-light">
                    <tr>
                        <th class="px-4 py-3">#</th>
                        <th class="px-4 py-3">Name</th>
                        <th class="px-4 py-3">Email</th>
                        <th class="px-4 py-3">Role</th>
                        <th class="px-4 py-3">Instance & Access</th>
                        <th class="px-4 py-3">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="border-bottom">
                        <td data-label="#" class="px-4 py-3"><?php echo e($loop->iteration); ?></td>
                        <td data-label="Name" class="px-4 py-3">
                            <div class="d-flex flex-column">
                                <span class="font-weight-bold"><?php echo e($user->name); ?></span>
                            </div>
                        </td>
                        <td data-label="Email" class="px-4 py-3"><?php echo e($user->email); ?></td>
                        <td data-label="Role" class="px-4 py-3">
                            <span class="badge badge-info"><?php echo e($user->getRoleNames()); ?></span>
                        </td>
                        <td data-label="Instance & Access" class="px-4 py-3">
                            <form action="<?php echo e(route('setInstanceAndAccess', ['user' => $user->id])); ?>" method="POST" class="instance-access-form">
                                <?php echo csrf_field(); ?>
                                <div class="form-container">
                                    <div class="form-group mb-2">
                                        <label for="access_token_<?php echo e($user->id); ?>" class="sr-only">Access Token</label>
                                        <input type="text" id="access_token_<?php echo e($user->id); ?>" name="access_token" class="form-control form-control-sm" placeholder="Access Token" value="<?php echo e($user->instanceAccess?->access_token); ?>">
                                    </div>
                                    <div class="form-group mb-2">
                                        <label for="instance_id_<?php echo e($user->id); ?>" class="sr-only">Instance ID</label>
                                        <input type="text" id="instance_id_<?php echo e($user->id); ?>" name="instance_id" class="form-control form-control-sm" placeholder="Instance Id" value="<?php echo e($user->instanceAccess?->instance_id); ?>">
                                    </div>
                                </div>
                                <div class="form-group mb-2">
                                    <button type="submit" class="btn btn-success btn-sm w-100 mb-2">Save</button>
                                    <a href="<?php echo e(route('clearInstanceAndAccess', ['user' => $user->id])); ?>" class="btn btn-secondary btn-sm w-100">Clear</a>
                                </div>
                            </form>
                        </td>
                        <td data-label="Action" class="px-4 py-3">
                            <div class="d-flex flex-column gap-2">
                                <a href="<?php echo e(route('user.edit', ['user' => $user])); ?>" class="btn btn-sm btn-outline-primary w-100" aria-label="Edit user">
                                    <i class="fas fa-edit mr-1"></i><span>Edit</span>
                                </a>
                                <a href="<?php echo e(route('user.delete', ['user' => $user])); ?>" class="btn btn-sm btn-outline-danger w-100" aria-label="Delete user">
                                    <i class="fas fa-trash mr-1"></i><span>Delete</span>
                                </a>
                                <a href="<?php echo e(route('user.assignedNumbers', ['user' => $user])); ?>" class="btn btn-sm btn-outline-info w-100" aria-label="View assigned numbers">
                                    <i class="fas fa-list-ol mr-1"></i><span>Numbers</span>
                                </a>
                                <a href="<?php echo e(route('user.permissions', ['user' => $user])); ?>" class="btn btn-sm btn-outline-secondary w-100" aria-label="Manage user permissions">
                                    <i class="fas fa-key mr-1"></i><span>Permissions</span>
                                </a>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<style>
    .table {
        border-collapse: separate;
        border-spacing: 0 0.5rem;
    }

    .table tr {
        background-color: #fff;
        box-shadow: 0 2px 4px rgba(0,0,0,0.05);
        transition: all 0.3s ease;
    }

    .table tr:hover {
        transform: translateY(-2px);
        box-shadow: 0 4px 6px rgba(0,0,0,0.1);
    }

    .table td, .table th {
        vertical-align: middle;
    }

    .btn-sm {
        padding: 0.375rem 0.75rem;
        font-size: 0.875rem;
        border-radius: 0.25rem;
        transition: all 0.3s ease;
    }

    .btn-sm:hover {
        transform: translateY(-1px);
        box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    }

    .form-control:focus {
        box-shadow: 0 0 0 0.2rem rgba(0,123,255,.25);
    }

    @media (max-width: 991.98px) {
        .table thead {
            display: none;
        }

        .table, .table tbody, .table tr, .table td {
            display: block;
            width: 100%;
        }

        .table tr {
            margin-bottom: 1.5rem;
            border: 1px solid #e9ecef;
            border-radius: 0.5rem;
            overflow: hidden;
            box-shadow: 0 2px 4px rgba(0,0,0,0.05);
        }

        .table td {
            padding: 1rem;
            text-align: left;
            position: relative;
            border-bottom: 1px solid #e9ecef;
        }

        .table td:last-child {
            border-bottom: none;
        }

        .table td::before {
            content: attr(data-label);
            font-weight: bold;
            text-transform: uppercase;
            font-size: 0.75rem;
            color: #6c757d;
            display: block;
            margin-bottom: 0.5rem;
        }

        .instance-access-form {
            background-color: #f8f9fa;
            padding: 1rem;
            border-radius: 0.5rem;
            margin-top: 0.5rem;
        }

        .btn-sm {
            width: 100%;
            margin-bottom: 0.5rem;
        }

        .d-flex.flex-column {
            gap: 0.5rem !important;
        }
    }

    @media (min-width: 992px) {
        .table th:nth-child(1) { width: 5%; }
        .table th:nth-child(2) { width: 20%; }
        .table th:nth-child(3) { width: 20%; }
        .table th:nth-child(4) { width: 10%; }
        .table th:nth-child(5) { width: 25%; }
        .table th:nth-child(6) { width: 20%; }

        .instance-access-form {
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .instance-access-form .form-group {
            flex: 1;
            margin-bottom: 0;
        }

        .instance-access-form .btn {
            white-space: nowrap;
        }
    }
</style>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dash_layouts.aap', ['title' => 'All Users'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\work1\callingManagement\resources\views/dashboard/user/index.blade.php ENDPATH**/ ?>