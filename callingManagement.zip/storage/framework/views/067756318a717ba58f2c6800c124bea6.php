<?php $__env->startSection('content'); ?>



        <div class="card-body">
            <form action="<?php echo e(route('demo.records')); ?>" method="GET" class="form-inline">
                <?php echo csrf_field(); ?>
                <div class="form-group mx-sm-3 mb-2">
                    <label for="date" class="sr-only">Date</label>
                    <input type="date" class="form-control" id="date" name="date" placeholder="Date">
                </div>
                <button type="submit" class="btn btn-primary mb-2">Filter</button>
                <a href="<?php echo e(route('demo.records')); ?>" class="btn btn-secondary mb-2 ml-2">Clear</a>
            </form>
        </div>



    <div class="card">
        <div class="card-body">
            <table id="example1" class="table table-bordered table-striped">
                <thead>
                <tr>
                    <th>#</th>
                    <th>Name</th>
                    <th>Number</th>
                    <th>Demo Name</th>
                    <th>Custom Message</th>
                    <th>Sent By</th>
                    <th>Sent At</th>
                </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $demoRecords; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $record): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td><?php echo e($record->number->business_name); ?></td>
                            <td><?php echo e($record->number->phone_number); ?></td>
                            <td><?php echo e($record->demo?->name); ?></td>
                            <td><?php echo $record->custom_message; ?></td>
                            <td><?php echo e($record->user->name); ?></td>
                            <td><?php echo e($record->created_at->format('D-m h:i')); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        <!-- /.card-body -->
    </div>

    <!-- /.card -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('dash_layouts.aap', ['title' => 'Demo Records'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\work1\callingManagement\resources\views/dashboard/demo/records.blade.php ENDPATH**/ ?>