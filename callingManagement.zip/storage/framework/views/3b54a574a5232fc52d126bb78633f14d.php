<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-body">
            <form role="form" action="<?php echo e(route('role.store')); ?>" method="post" >
                <?php echo csrf_field(); ?>
                <div class="form-group mb-3">
                    <input name="name" type="text" class="form-control" placeholder="Role Name" />
                </div>
                <div class="form-group mb-3">
                    <button type="submit" class="btn btn-primary">Submit</button>
                </div>
            </form>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dash_layouts.aap', ['title' => 'Create Role'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\work1\callingManagement\resources\views/dashboard/role/create.blade.php ENDPATH**/ ?>