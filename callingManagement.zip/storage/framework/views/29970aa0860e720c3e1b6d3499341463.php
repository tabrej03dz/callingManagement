<?php $__env->startSection('content'); ?>
    <!-- general form elements -->
    <div class="card">
        <!-- /.card-header -->
        <!-- form start -->
        <form role="form" action="<?php echo e(route('status.store')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <div class="card-body">
                <div class="form-group mb-3">
                    <input name="name" type="text" class="form-control" placeholder="Name"/>
                </div>
                <button type="submit" class="btn btn-primary">Submit</button>
            </div>

        </form>
    </div>
    <!-- /.card -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dash_layouts.aap', ['title' => 'Create Status'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\work1\callingManagement\resources\views/dashboard/status/create.blade.php ENDPATH**/ ?>