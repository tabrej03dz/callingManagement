<?php $__env->startSection('content'); ?>
    <div class="row justify-content-center" >
        <div class="col-md-6">
            <div class="card">
                <div class="card-body">
                    <form role="form" action="<?php echo e(route('callRecord.store', ['number' => $number->id])); ?>" method="post" enctype="multipart/form-data" >
                        <?php echo csrf_field(); ?>

                        <div class="form-group mb-3">
                            <select name="status" class="form-control custom-select">
                                <option value="">Response</option>
                                <option value="call pick" <?php echo e(old('status') == 'call pick' ? 'selected' : ''); ?>>Call Pick</option>
                                <option value="call not pick" <?php echo e(old('status') == 'call not pick' ? 'selected' : ''); ?>>Call Not Pick</option>
                                <option value="call back" <?php echo e(old('status') == 'call back' ? 'selected' : ''); ?>>Call Back</option>
                            </select>
                        </div>

                        <div class="form-group mb-3">
                            <select name="number_status" class="form-control custom-select">
                                <option value="">Number Status</option>
                                <option value="interested" <?php echo e(old('number_status') == 'interested' ? 'selected' : ''); ?>>Interested</option>
                                <option value="not interested" <?php echo e(old('number_status') == 'not interested' ? 'selected' : ''); ?>>Not Interested</option>
                                <option value="wrong number" <?php echo e(old('number_status') == 'wrong number' ? 'selected' : ''); ?>>Wrong Number</option>
                                <option value="wrong number" <?php echo e(old('number_status') == 'converted' ? 'selected' : ''); ?>>Converted</option>
                            </select>
                        </div>

                        <div class="form-group mb-3">
                            <label for="">Price</label>
                            <input name="converted_price" type="text" class="form-control" placeholder="Price" value="<?php echo e(old('converted_price')); ?>"/>
                        </div>

                        <div class="form-group mb-3">
                            <textarea name="description" id="description" cols="30" rows="5" class="form-control" placeholder="Description" style="resize: none;"><?php echo e(old('description')); ?></textarea>
                        </div>
                        <div class="form-group mb-3">
                            <label for="">Call back time</label>
                            <input name="date_and_time" type="datetime-local" class="form-control" placeholder="Have to call" value="<?php echo e(old('date_and_time')); ?>"/>
                        </div>

                        <div class="form-group mb-3">
                            <input name="send_message" id="send_message" type="checkbox" value="true"/>
                            <label for="send_message">Do you want to send message to this number</label>
                        </div>

                        <div class="form-group mb-3">
                            <button type="submit" class="btn btn-primary">Submit</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dash_layouts.aap', ['title' => 'Create Call Record'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\work1\callingManagement\resources\views/dashboard/callRecord/form.blade.php ENDPATH**/ ?>